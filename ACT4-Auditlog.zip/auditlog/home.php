
<?php 
session_start();

if (isset($_SESSION['id']) && isset($_SESSION['username'])) {

 ?>
<!DOCTYPE html>
<html>
<head>
	<style>
	body{
			margin: 0;
			padding: 0;
			background: url(img/background.jpg);
			background-size: cover;
		
			font-family: 'Poppins', sans-serif
			background-repeat: no-repeat;		}
    h1 {
            width:500px;
            margin: 0 auto;
            background: transparent;
            text-align: center;
            position: absolute;
            top: 100px;
            left: 400px;
        }
        [type="submit"]{
			border: none;
			outline: none;
			height: 40px;
			background: transparent;
			color: #fff;
			font-size: 18px;
			border border-radius: 20px;
			position: absolute;
			top: 200px;
			left: 200px;
		}
        
		
		</style>
	<title>HOME</title>
	
</head>
<body>
	
     <h1>Welcome, <?php echo $_SESSION['username']; ?></h1>
	
   <center><button style="position: absolute; top: 150px; left: 600px; width: 100px; background-color: salmon;">  <a href="logout.php">Logout</a> </button></center><br/>
	<h1><center><button type="submit">  <a href="display.php" >View Activity</a> </button></center></h1>

</body>
</html>

<?php 
}else{
     header("Location: index.php");
     exit();
}
 ?>                            		                            
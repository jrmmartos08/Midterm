<?php 
session_start();
  
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
    
</head>
<body>
    
    <div class="page-header">
        <h1><b style="color: white; text-shadow: none; font-size: 100px;position: absolute; top: 50px; ;left: 400px;">Welcome Admin! </h1>
    </div>
    <p>
       
        <a style="color: gold; font-size: 25px; position: absolute; left: 350px; top: -300px;" href="logout.php" class="btn btn-danger">Logout</a>
    </p>
    
</body>
</html>
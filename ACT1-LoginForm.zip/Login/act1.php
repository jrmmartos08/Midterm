
<html>
<head>
  <title>Activity 1</title>
  
  <link rel="stylesheet" type="text/css" href="Log.css">
</head>
<body>
  <div class="container">
    <section class="Login-form">
      <h2>  </h2>

      <form action="welcome.php" method="post">

        <input type="text" placeholder="Username" name="user">
        <input type="Password" placeholder="Password" name="pass">
        <input name="Login" type="submit" value="LOGIN">
        

      </form>
    </section>
  </div>
</body>
</html>
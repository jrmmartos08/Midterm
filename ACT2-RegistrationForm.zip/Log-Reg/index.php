<?php
// session_start();

  include("connect.php");
  include("functions.php");

//   $user_data = check_login($con);

//       //read from the database
          
//  $uname = $_POST['username'];
//  $pass = $_POST['password'];
//           if ( $_POST['username'] == $uname && $_POST['password'] != $pass) {

//           	echo "<script> alert 'Invalid Password' </script>";
//           	echo "<script>location.href='login.php'</script>";

//           }

//           else if ($_POST['username'] != $uname && $_POST['password'] == $pass) {

//           	echo "<script> alert 'Invalid Username'</script>";
//           	echo "<script>location.href='login.php'</script>";

//           }

//           else if ($_POST['username'] != $uname && $_POST['password'] != $pass) {

//           	echo "<script> alert 'User does not Exist' </script>";
//           	echo "<script>location.href='login.php'</script>";
//           }

//           else {

//         $sql = "SELECT * FROM users WHERE username='$uname' AND password='$pass";
// 		$result = mysqli_query($con, $sql);

//        		if (mysqli_num_rows($result) === 1) {
// 			$row = mysqli_fetch_assoc($result);
// 			if ($row['username'] === $uname && $row['password'] === $pass) {
// 				$_SESSION['username'] = $row['username'];
// 				$_SESSION['email'] = $row['email'];
// 				$_SESSION['id'] = $row['id'];
// 				echo "<script>location.href='index.php'</script>";
		 

//     		}

//     }
// }
// ?>


 <html>
 <head>
  <title>WELCOME</title>
 </head>
 <body>

 <link rel="stylesheet" type="text/css" href="design.css">
 <section class="Logout">
// <?php 


//  $uname = $_POST['username'];
//  $pass = $_POST['password'];
//           if ( $_POST['username'] == $uname && $_POST['password'] != $pass) {

//           	echo "<script> alert 'Invalid Password' </script>";
//           	echo "<script>location.href='login.php'</script>";

//           }

//           else if ($_POST['username'] != $uname && $_POST['password'] == $pass) {

//           	echo "<script> alert 'Invalid Username'</script>";
//           	echo "<script>location.href='login.php'</script>";

//           }

//           else if ($_POST['username'] != $uname && $_POST['password'] != $pass) {

//           	echo "<script> alert 'User does not Exist' </script>";
//           	echo "<script>location.href='login.php'</script>";
//           }

//           else {

//         $sql = "SELECT * FROM users WHERE username='$uname' AND password='$pass";
// 		$result = mysqli_query($con, $sql);

//        		if (mysqli_num_rows($result) === 1) {
// 			$row = mysqli_fetch_assoc($result);
// 			if ($row['username'] === $uname && $row['password'] === $pass) {
// 				$_SESSION['username'] = $row['username'];
// 				$_SESSION['email'] = $row['email'];
// 				$_SESSION['id'] = $row['id'];
// 				echo "<script>location.href='index.php'</script>";
		 

//     		}
//     	}
//     }
$usrnm="ADMIN";
$psswrd="ADMIN123";
$null= null;

session_start();

if(isset($_SESSION['id'])){

  echo "<h1 align='center'> WELCOME ".$_SESSION['id']."</h1>";

  echo "<br><a href='logout.php'><input type=button value=LOGOUT name=logout></a>";
}

else {

 if ($_POST['username']==$usrnm && $_POST['password']==$psswrd){

    $_SESSION['id']=$usrnm;
    echo "<script>location.href='index.php'</script>";

  
  }


else if ($_POST['username']==$usrnm && $_POST['password']!=$psswrd){

  echo "<script> alert('Wrong Password!') </script>";
  session_destroy();

echo "<script>location.href='login.php'</script>";
session_destroy();

}

else if ($psswrd==$null){

echo "<script>alert('No Password!')</script>";
session_destroy();

echo "<script>location.href='login.php'</script>";
session_destroy();

}

else if ($usrnm==$null){

  echo "<script>alert('No Username!')</script>";
  session_destroy();

echo "<script>location.href='login.php'</script>";
session_destroy();

}

else{

echo "<script>alert('User does not exist!')</script>";
session_destroy();

echo "<script>location.href='login.php'</script>";
session_destroy();

}
}
// else {

// echo "<script>location.href='act1.php'</script>";
// session_destroy();
// }


?>
</section>
</body>
</html>
<?php
session_start();

include("functions.php");
include("connect.php");
  $_SESSION;


 if($_SERVER['REQUEST_METHOD'] == "POST") {

      $name      = $_POST['name'];
      $user_name = $_POST['username'];
      $email     = $_POST['email'];
      $password  = $_POST['password'];
      $confirm   = $_POST['confirm'];
      

      // if(strlen($password=8)) {

      //   echo " <script> alert('Success') </script>";
      //   echo "<script>location.href='login.php'</script>";
      // }

      if (strlen($password)<8){

        echo " <script> alert('Password must be 8 Characters') </script>";
        echo "<script>location.href='register.php'</script>";

      }


      else if ($password != $confirm){

        echo " <script> alert('Password didnt match') </script>";
        echo "<script>location.href='register.php'</script>";
         
     }

      else if(is_numeric($name)) {
      
        echo " <script> alert('Please Enter a valid Name') </script>";
        echo "<script>location.href='register.php'</script>";

    
    }

    else if(!preg_match("#[0-9]+#",$password)){
    
      echo " <script> alert('Password need atleast One(1) Number') </script>";
        echo "<script>location.href='register.php'</script>";
  
     }

     else if(!preg_match("#[\W]+#",$password))  {
        echo " <script> alert('Password Need Atleast One(1) Special Character') </script>";
        echo "<script>location.href='register.php'</script>";
  
    }
    
    else if(!preg_match("#[a-z]+#",$password))  {
     echo " <script> alert('Need Atleast One(1) Lowercase') </script>";
        echo "<script>location.href='register.php'</script>";
  
    }

     else if(!preg_match("#[A-Z]+#",$password))  {
     echo " <script> alert('Need Atleast One(1) Uppercase') </script>";
        echo "<script>location.href='register.php'</script>";
  
    }


    else {

      //submit to database

      echo " <script> alert('You are now Registered!') </script>";
      echo "<script>location.href='login.php'</script>";     

        $query = "insert into users (name,email_address,username,password) values ('$name','$email','$user_name','$password')";

        mysqli_query($con, $query);



    }
}

?>


<html>
<head>
  <title>LOGIN</title>
  
  <link rel="stylesheet" type="text/css" href="design.css">
</head>

<body>
  <div id="container">
    <section class="Login-form">
      <h2>  </h2>

      <form action="index.php" method="post">

         <input type="text"      name="username"       placeholder="Username" required>
        <input type="password"   name="password"         placeholder="Password" required>
        <input name="Login" type="submit" value="LOGIN">
      </form>
      &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;  OR
       <br> <br>
      <form action="register.php" >
        <input type="submit" name="sign_up" value="SIGN UP">

      </form>
    </section>
   </div>
  </body>
</html>

 
      
<?php
session_start();

  include("connect.php");
  include("functions.php");

 
//  if($_SERVER['REQUEST_METHOD'] == "POST") {

//       $name      = $_POST['name'];
//       $user_name = $_POST['username'];
//       $email     = $_POST['email'];
//       $password  = $_POST['password'];
//       $confirm   = $_POST['confirm'];

//       if($password == $confirm) {

//         echo " <script> alert('Success') </script>";
//         echo "<script>location.href='login.php'</script>";
//       }

//       else if ($_POST['password'] != $_POST['confirm']){

//         echo " <script> alert('Password didnt match') </script>";
//         echo "<script>location.href='register.php'</script>";
         
//   }
//     else {

//        echo " <script> alert('Something went wrong') </script>";
//         echo "<script>location.href='register.php'</script>";
//     }
// }
?>

<html>
<head>
  <title>REGISTRATION FORM</title>
  
  <link rel="stylesheet" type="text/css" href="design.css">
</head>

<body>
  <div id="register">
    <section class="Reg-form">
      <h2> SIGN UP </h2>

      <form action="login.php" method="post">

        <input type="text"      name="name"           placeholder="Name" required >
        <input type="email"     name="email"          placeholder="Email Address" required>
        <input type="text"      name="username"       placeholder="Username" required>
        <input type="password"  name="password"       placeholder="Password" required>
        <input type="password"  name="confirm"        placeholder="Confirm Password" required>

         <input name="regis" type="submit" value="REGISTER">
      </form>
      <form action="login.php" >
       &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;  OR
       <br> <br> <input type="submit" name="Login" value="LOGIN">

      </form>
    </section>
   </div>
  </body>
</html>